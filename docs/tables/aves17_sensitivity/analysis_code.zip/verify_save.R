.libPaths(c('/home/arct/R/cf_model_comparison_20261013_R46','/home/arct/R/x86_64-pc-linux-gnu-library/4.5',.libPaths()))
library(brms)
out <- 'sensitivity_aves17_619_20261106'
old <- readRDS(file.path(out,'template_recompiled.rds'))
f <- readRDS(file.path(out,'diagnostic_only_20_iterations.rds'))
a <- readRDS(file.path(out,'matrices/tree_01.rds'))
target <- file.path(out,'diagnostic_save_test.rds')
saveRDS(f,paste0(target,'.tmp'))
stopifnot(identical(names(f$data),names(old$data)),nrow(f$data)==619,
 all(vapply(names(old$data),function(n)identical(f$data[[n]],old$data[[n]]),logical(1))),
 max(abs(f$data2$phylo_mat-a))<1e-10)
stopifnot(file.rename(paste0(target,'.tmp'),target))
reloaded <- readRDS(target)
print(all.equal(reloaded$data,f$data))
stopifnot(identical(names(reloaded$data),names(f$data)),nrow(reloaded$data)==619,
 all(vapply(names(f$data),function(n)identical(reloaded$data[[n]],f$data[[n]]),logical(1))),
 max(abs(reloaded$data2$phylo_mat-a))<1e-10)
writeLines('PASS: all columns identical, new matrix exact, save and reload successful',file.path(out,'SAVE_TEST_PASSED'))
