.libPaths(c('/home/arct/R/cf_model_comparison_20261013_R46','/home/arct/R/x86_64-pc-linux-gnu-library/4.5',.libPaths()))
library(brms)
library(posterior)
out <- 'sensitivity_aves17_619_20261106'
dir.create(file.path(out,'results'),showWarnings=FALSE)
summ <- function(z) c(mean=mean(z),median=median(z),lower=unname(quantile(z,.025)),upper=unname(quantile(z,.975)))
process <- function(f,id) {
 d <- as_draws_df(f)
 p <- d$sd_species_phylo_brms__Intercept^2
 n <- d$sd_species_nonphylo__Intercept^2
 vals <- data.frame(prevalence=plogis(d$b_Intercept),H2_phylo=p/(p+n),variance_phylo=p,variance_species=n,variance_study=d$sd_Study_ID__Intercept^2,phi=d$phi)
 s <- as.data.frame(t(vapply(vals,summ,numeric(4))))
 s$parameter <- rownames(s); s$model <- id; rownames(s) <- NULL
 dg <- summarise_draws(as_draws_array(f),rhat,ess_bulk,ess_tail)
 np <- nuts_params(f)
 diag <- data.frame(model=id,max_rhat=max(dg$rhat,na.rm=TRUE),min_bulk_ess=min(dg$ess_bulk,na.rm=TRUE),min_tail_ess=min(dg$ess_tail,na.rm=TRUE),divergences=sum(np$Value[np$Parameter=='divergent__']),max_treedepth_hits=sum(np$Value[np$Parameter=='treedepth__']>=15))
 list(summary=s,draws=vals,diagnostics=diag)
}
base <- process(readRDS('models/model_overall_study.rds'),'Aves_1.6_reference')
write.csv(base$summary,file.path(out,'results','reference_estimates.csv'),row.names=FALSE)
write.csv(base$diagnostics,file.path(out,'results','reference_diagnostics.csv'),row.names=FALSE)
if('reference-only' %in% commandArgs(trailingOnly=TRUE)) quit(status=0)
all <- parallel::mclapply(1:50,function(j) {
 path <- file.path(out,'fits',sprintf('tree_%02d.rds',j))
 stopifnot(file.exists(paste0(path,'.done')))
 process(readRDS(path),sprintf('Aves_1.7_tree_%02d',j))
},mc.cores=4)
stopifnot(!any(vapply(all,inherits,logical(1),'try-error')))
diagnostics <- do.call(rbind,c(list(base$diagnostics),lapply(all,`[[`,'diagnostics')))
write.csv(diagnostics,file.path(out,'results','diagnostics.csv'),row.names=FALSE)
per_tree <- do.call(rbind,lapply(all,`[[`,'summary'))
write.csv(per_tree,file.path(out,'results','per_tree_estimates.csv'),row.names=FALSE)
# Equal numbers of posterior draws give each sampled tree equal weight.
stopifnot(length(unique(vapply(all,function(x)nrow(x$draws),integer(1))))==1)
pooled <- do.call(rbind,lapply(all,`[[`,'draws'))
ps <- as.data.frame(t(vapply(pooled,summ,numeric(4))))
ps$parameter <- rownames(ps); ps$model <- 'Aves_1.7_equal_weight_50_trees'; rownames(ps)<-NULL
write.csv(rbind(base$summary,ps),file.path(out,'results','comparison.csv'),row.names=FALSE)
saveRDS(pooled,file.path(out,'results','pooled_parameter_draws.rds'))
flag <- with(diagnostics[-1,],max_rhat>1.01 | min_bulk_ess<400 | min_tail_ess<400 | divergences>0 | max_treedepth_hits>0)
write.csv(diagnostics[-1,][flag,],file.path(out,'results','models_requiring_review.csv'),row.names=FALSE)
writeLines(if(any(flag)) 'REVIEW_REQUIRED' else 'DIAGNOSTICS_PASSED',file.path(out,'results','STATUS'))
library(ggplot2)
plotdata <- rbind(per_tree,base$summary,ps)
plotdata <- plotdata[plotdata$parameter %in% c('prevalence','H2_phylo'),]
plotdata$kind <- ifelse(plotdata$model=='Aves_1.6_reference','Aves 1.6 reference',ifelse(plotdata$model=='Aves_1.7_equal_weight_50_trees','Aves 1.7 pooled','Aves 1.7 individual tree'))
plotdata$label <- ifelse(plotdata$kind=='Aves 1.7 individual tree',sub('Aves_1.7_tree_','Tree ',plotdata$model),plotdata$kind)
plotdata$label <- factor(plotdata$label,levels=c(sprintf('Tree %02d',50:1),'Aves 1.7 pooled','Aves 1.6 reference'))
isprev <- plotdata$parameter=='prevalence'
plotdata[isprev,c('mean','lower','upper')] <- plotdata[isprev,c('mean','lower','upper')]*100
plotdata$panel <- ifelse(isprev,'Mixed-paternity prevalence (%)','Species-level phylogenetic heritability')
g <- ggplot(plotdata,aes(x=mean,y=label,colour=kind))+geom_segment(aes(x=lower,xend=upper,yend=label),linewidth=.35)+geom_point(size=1.5)+facet_wrap(~panel,scales='free_x')+scale_colour_manual(values=c('Aves 1.6 reference'='#A84432','Aves 1.7 pooled'='#156B63','Aves 1.7 individual tree'='#66788A'))+labs(x='Posterior mean and 95% interval',y=NULL,colour=NULL)+theme_bw(base_size=10)+theme(legend.position='bottom',panel.grid.minor=element_blank(),panel.grid.major.y=element_blank())
ggsave(file.path(out,'results','aves17_sensitivity.pdf'),g,width=10,height=12)
ggsave(file.path(out,'results','aves17_sensitivity.png'),g,width=10,height=12,dpi=180)
range_summary <- do.call(rbind,lapply(split(per_tree,per_tree$parameter),function(d)data.frame(parameter=d$parameter[1],min_tree_mean=min(d$mean),max_tree_mean=max(d$mean),sd_tree_means=stats::sd(d$mean))))
write.csv(range_summary,file.path(out,'results','between_tree_variation.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'results','sessionInfo.txt'))
