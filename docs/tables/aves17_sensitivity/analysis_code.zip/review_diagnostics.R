.libPaths(c('/home/arct/R/cf_model_comparison_20261013_R46','/home/arct/R/x86_64-pc-linux-gnu-library/4.5',.libPaths()))
library(brms)
library(posterior)
out <- 'sensitivity_aves17_619_20261106'
for(j in c(14,21,41,42,47)) {
 f <- readRDS(file.path(out,'fits',sprintf('tree_%02d.rds',j)))
 d <- summarise_draws(as_draws_array(f),rhat,ess_bulk,ess_tail)
 cat('\nTREE',j,'\n')
 print(as.data.frame(d[d$rhat>1.01 & !is.na(d$rhat),]),row.names=FALSE)
 print(as.data.frame(d[grepl('^(b_|sd_|phi$)',d$variable),]),row.names=FALSE)
}
