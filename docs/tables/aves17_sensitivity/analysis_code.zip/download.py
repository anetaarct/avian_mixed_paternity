import urllib.request, json, pathlib, hashlib, subprocess
out=pathlib.Path('/home/arct/mixed_paternity_final/sensitivity_aves17_619_20261106')
out.mkdir(exist_ok=True)
req=urllib.request.Request('https://api.github.com/repos/McTavishLab/AvesData/commits/main',headers={'User-Agent':'avian-paternity-reproducibility'})
sha=json.load(urllib.request.urlopen(req))['sha']
name='dated_rand_sample_clements.tre'
url=f'https://raw.githubusercontent.com/McTavishLab/AvesData/{sha}/Tree_versions/Aves_1.7/Clements2025/{name}'
p=out/name
urllib.request.urlretrieve(url,p)
blob=hashlib.sha1(b'blob '+str(p.stat().st_size).encode()+b'\0'+p.read_bytes()).hexdigest()
assert blob=='8ba05e2957b3595c94d954ca54eb2bb23440a01f',blob
manifest={'commit':sha,'url':url,'git_blob':blob,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'seed':20261106,'sample_without_replacement':50,'records':619}
(out/'tree_source.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
