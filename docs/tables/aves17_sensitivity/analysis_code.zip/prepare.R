.libPaths(c('/home/arct/R/cf_model_comparison_20261013_R46','/home/arct/R/x86_64-pc-linux-gnu-library/4.5',.libPaths()))
library(brms)
library(ape)
out <- 'sensitivity_aves17_619_20261106'
dir.create(file.path(out,'matrices'),showWarnings=FALSE)
dir.create(file.path(out,'fits'),showWarnings=FALSE)
dir.create(file.path(out,'logs'),showWarnings=FALSE)
old <- readRDS('models/model_overall_study.rds')
stopifnot(nrow(old$data)==619,length(unique(old$data$species_phylo_brms))==375)
saveRDS(old$data,file.path(out,'analysis_data.rds'))
write.csv(old$data,file.path(out,'analysis_data.csv'),row.names=FALSE)
writeLines(capture.output(old$prior),file.path(out,'priors.txt'))
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
source_lines <- readLines(file.path(out,'dated_rand_sample_clements.tre'))
tree_lines <- source_lines[grepl('^\\s*\\(',source_lines)]
stopifnot(length(tree_lines)==100)
set.seed(20261106)
ids <- sort(sample(seq_along(tree_lines),50,replace=FALSE))
write.csv(data.frame(model=seq_along(ids),source_tree=ids,seed=20261106),file.path(out,'selected_trees.csv'),row.names=FALSE)
labels <- rownames(old$data2$phylo_mat)
oldtree <- readRDS('data/tree_analysis.rds')
rebuilt <- vcv.phylo(oldtree,corr=TRUE)[labels,labels]
stopifnot(max(abs(rebuilt-old$data2$phylo_mat))<1e-8)
audit <- list()
for(j in seq_along(ids)) {
 t <- read.tree(text=tree_lines[ids[j]])
 t$tip.label <- gsub(' ','_',t$tip.label,fixed=TRUE)
 missing <- setdiff(labels,t$tip.label)
 if(length(missing)) stop(paste('Missing species:',paste(missing,collapse=', ')))
 t <- keep.tip(t,labels)
 a <- vcv.phylo(t,corr=TRUE)[labels,labels]
 stopifnot(all(is.finite(a)),max(abs(diag(a)-1))<1e-10)
 ev <- min(eigen(a,symmetric=TRUE,only.values=TRUE)$values)
 stopifnot(ev>0)
 saveRDS(a,file.path(out,'matrices',sprintf('tree_%02d.rds',j)))
 write.tree(t,file=file.path(out,'matrices',sprintf('tree_%02d.tre',j)))
 audit[[j]] <- data.frame(model=j,source_tree=ids[j],tips=length(t$tip.label),min_eigenvalue=ev,max_correlation_change=max(abs(a-old$data2$phylo_mat)))
}
write.csv(do.call(rbind,audit),file.path(out,'tree_audit.csv'),row.names=FALSE)
# Recompile the unchanged Stan program for the currently installed R/runtime.
sm <- rstan::stan_model(model_code=stancode(old),model_name='aves17_overall_619')
old$fit@stanmodel <- sm
saveRDS(old,file.path(out,'template_recompiled.rds'))
writeLines('Preparation and fresh compilation complete',file.path(out,'PREPARED'))
