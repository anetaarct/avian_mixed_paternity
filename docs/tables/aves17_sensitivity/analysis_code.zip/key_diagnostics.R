.libPaths(c('/home/arct/R/cf_model_comparison_20261013_R46','/home/arct/R/x86_64-pc-linux-gnu-library/4.5',.libPaths()))
library(brms)
library(posterior)
out <- 'sensitivity_aves17_619_20261106'
ans <- parallel::mclapply(1:50,function(j) {
 f <- readRDS(file.path(out,'fits',sprintf('tree_%02d.rds',j)))
 a <- as.array(f,pars=c('b_Intercept','sd_species_phylo_brms__Intercept','sd_species_nonphylo__Intercept'))
 p <- a[,,'sd_species_phylo_brms__Intercept']^2
 n <- a[,,'sd_species_nonphylo__Intercept']^2
 quantities <- list(H2_phylo=p/(p+n),prevalence=plogis(a[,,'b_Intercept']))
 do.call(rbind,lapply(names(quantities),function(nm) {
  z <- quantities[[nm]]
  data.frame(model=j,parameter=nm,rhat=posterior::rhat(z),ess_bulk=posterior::ess_bulk(z),ess_tail=posterior::ess_tail(z),mcse_mean=posterior::mcse_mean(z))
 }))
},mc.cores=4)
stopifnot(!any(vapply(ans,inherits,logical(1),'try-error')))
write.csv(do.call(rbind,ans),file.path(out,'results','key_parameter_diagnostics.csv'),row.names=FALSE)
d <- readRDS(file.path(out,'results','pooled_parameter_draws.rds'))
stopifnot(nrow(d)==50*20000)
keep <- !rep(1:50,each=20000) %in% c(14,21,41,42,47)
summ <- function(z)c(mean=mean(z),lower=unname(quantile(z,.025)),upper=unname(quantile(z,.975)))
s <- as.data.frame(t(vapply(d[keep,],summ,numeric(3))))
s$parameter <- rownames(s)
write.csv(s,file.path(out,'results','diagnostic_45_tree_check.csv'),row.names=FALSE)
