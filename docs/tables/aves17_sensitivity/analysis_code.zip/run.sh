#!/usr/bin/env bash
set -euo pipefail
cd /home/arct/mixed_paternity_final
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
out=sensitivity_aves17_619_20261106
test -f "$out/PREPARED"
test -f "$out/SAVE_TEST_PASSED"
# Eight models at a time, four chains each: at most 32 sampling processes.
seq 1 50 | xargs -P 8 -I '{}' bash -c 'Rscript sensitivity_aves17_619_20261106/fit_one.R "$1" > "sensitivity_aves17_619_20261106/logs/tree_$(printf %02d "$1").log" 2>&1' _ '{}'
date -Is > "$out/ALL_FITS_FINISHED"
