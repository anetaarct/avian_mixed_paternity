ACTIVE ANALYSIS — no new scientific results have been published yet.
2026-11-06 retry: initial batch lost unsaved fits because identical(f$data,old$data) rejected a changed data_name attribute. All actual columns were identical. Stopped only original batch process subtree, archived its logs as logs_failed_metadata_check, corrected column-wise validation, moved save before validation, tested save/reload successfully (SAVE_TEST_PASSED), restarted 50 fits with batch_retry.log. No initial fit is an accepted completed result. Diagnostic 20-iteration files are NOT scientific results.
Remote directory: /home/arct/mixed_paternity_final/sensitivity_aves17_619_20261106
Reference: /home/arct/mixed_paternity_final/models/model_overall_study.rds
Exact reference data: 619 rows, 375 species, 554 Study_IDs; original counts unchanged.
AvesData commit: 4af84f14f8f3df26bd4480202689b08ea0fc2c48
Tree file SHA256: e29d450285fe120f9b05dc8fca140f88d12fca38b3332b100938ab0be3a1e6c1
50 of 100 dated_rand_sample_clements.tre trees, seed 20261106, sampled without replacement.
run.sh: eight concurrent models, each four chains, 10000 iterations, 5000 warmup.
finish.sh: after ALL_FITS_FINISHED, run summarize.R. Results need explicit review.
Completion marker for each model: fits/tree_XX.rds.done (after data/matrix verification and save).
Primary reported prevalence remains conditional on zero random effects, matching reference 34.7062%.
Reference H2_phylo = 0.869069, interval 0.743601–0.957884.
Publication destinations: Overleaf project 6a18a4e7e209786fb564ced9, SM.tex; GitHub anetaarct/avian_mixed_paternity.
Local repository: ../polyandry_refits_20261105/repository (relative to outputs).
Do not publish provisional values or claim all diagnostics passed before reviewing results/STATUS.
Update supplement departures paragraph (currently says no tree replicates fitted), add subsection under overall summaries, and create separate website sensitivity chapter with plot, table, downloadable diagnostics and code.
Do not change the main model or other results in this task.
