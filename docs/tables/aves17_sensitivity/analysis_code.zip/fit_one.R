.libPaths(c('/home/arct/R/cf_model_comparison_20261013_R46','/home/arct/R/x86_64-pc-linux-gnu-library/4.5',.libPaths()))
library(brms)
out <- 'sensitivity_aves17_619_20261106'
j <- as.integer(commandArgs(trailingOnly=TRUE)[1])
stopifnot(j %in% 1:50,file.exists(file.path(out,'PREPARED')))
target <- file.path(out,'fits',sprintf('tree_%02d.rds',j))
if(file.exists(paste0(target,'.done'))) quit(status=0)
old <- readRDS(file.path(out,'template_recompiled.rds'))
a <- readRDS(file.path(out,'matrices',sprintf('tree_%02d.rds',j)))
start <- Sys.time()
f <- update(old,newdata=old$data,data2=list(phylo_mat=a),recompile=FALSE,
 chains=4,cores=4,iter=10000,warmup=5000,seed=20261106+j,
 control=list(adapt_delta=.99,max_treedepth=15),refresh=1000)
saveRDS(f,paste0(target,'.tmp'))
# brms::update changes only the descriptive data_name attribute. Check every
# actual data column and its order/type instead of this non-analytical label.
stopifnot(identical(names(f$data),names(old$data)),nrow(f$data)==619,
 all(vapply(names(old$data),function(n)identical(f$data[[n]],old$data[[n]]),logical(1))),
 max(abs(f$data2$phylo_mat-a))<1e-10)
stopifnot(file.rename(paste0(target,'.tmp'),target))
writeLines(capture.output(summary(f)),paste0(target,'.summary.txt'))
writeLines(as.character(Sys.time()-start),paste0(target,'.runtime.txt'))
writeLines(as.character(Sys.time()),paste0(target,'.done'))
